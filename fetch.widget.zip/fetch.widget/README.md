# Fetch-Übersicht

Shows stats such as system, network and weather information on your desktop. Requires Übersicht.
Most scripts are based on neofetch. Requires DarkskyAPI key for weather.

![Screenshot](screenshot-1.png?raw=true)
